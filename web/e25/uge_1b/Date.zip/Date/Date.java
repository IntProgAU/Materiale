/**
 * Models a date.
 * Assumes that all months have 30 days.
 * 
 * @author Kurt Jensen.
 * @version 2020-09-01.
 */
public class Date {

    private int day;
    private int month;
    private int year;

    /**
     * Creates a date for the day d-m-y.
     * @param d   day
     * @param m   month
     * @param y   year 
     */
    public Date(int d, int m, int y) {
        day = d;
        month = m;
        year = y;
    }

    /**
     * Sets the date to following day (next date).
     */
    public void nextDay() {
        day = day + 1;
        if(day > 30) {
            day = 1;
            month = month + 1;
            if(month > 12) {
                month = 1;
                year = year + 1;
            }
        }
    }

    /**
     * Sets the date to the date d days after this.
     * @param d   number of days
     */
    public void addDays(int d) {
        for (int i = 0; i < d; i++) {
            nextDay();
        }
    }

    /**
     * Returns a String representation of this date.
     * @return   String representation of this date
     */
    public String toString() {
        return day + "-" + month + "-" + year;
    }
}
