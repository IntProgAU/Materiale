/**
 * This class models a person.
 * @author Kurt Jensen
 * @version 2020-09-01
 */
public class Person {

    private String name;
    private int age;

    /**
     * Construct a new person with the given name and age.
     * @param n   name of the person
     * @param a   age of the person
     */
    public Person(String n, int a) {
        name = n;
        age = a;
    }

    /**
     * Returns the name of the person.
     * @return   name of the person
     */
    public String getName() {
        return name;
    }

    /**
     * Changes the name of the person.
     * @param n  new name
     */
    public void setName(String n) {
        name = n;
    }

    /**
     * Returns the person's age.
     * @return   person's age
     */
    public int getAge() {
        return age;
    }

    /**
     * Celebrate the person's birthday
     */
    public void birthday() {
        age= age + 1;
        System.out.println("Happy birthday " + name + "!");
    }

    /**
     * Is the person a teenager?
     * @return   true is the person is a teenager, otherwise false
     */ 
    public boolean isTeenager() { 
        return (13 <= age  &&  age <= 19); 
        
    }
    
    /**
     * @return   String representation of this Person
     */
    public String toString() {
        return name + ": " + age + " years";
    }
    
}
