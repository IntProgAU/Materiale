import java.util.Date;
/**
 * @author Kurt Jensen
 * @version 2017-01-12
 */
public class Driver {

    private Driver() {}

    public static void run(int no)
    {
        if (no < 0 || no > 6) {
            System.out.println("Parameter must be between 0 and 6");
        }
        else {
            String filename = "games/jp" + no + ".sud";
            System.out.println(filename);
            System.out.println();
            
            Grid g  = new Grid(filename);
            Solver s = new Solver(g);

            g.printGrid();
            s.tryAll();            
        }
    }
}
