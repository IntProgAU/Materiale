/**
 * @author Kurt Jensen
 * @version 2017-01-12
 */
public class Solver {

    private Grid g;

    public Solver(Grid g) {
        this.g = g;
    }

    public void setGrid(Grid g) { 
        this.g = g;
    }

    /**
     * Find and print the solution of this Sudoku
     */
    public void tryAll() {
        if ( g.allFilled() ) {
            g.printGrid();
        }
        else { 
            // try all values at next field
            Field previous= g.currentField();
            g.advanceToNextUnfilled();

            for ( int c= 1; c <= 9; c++ ) {
                if ( g.promissing(c) ) {
                    g.setFieldValue(c);
                    tryAll();
                }
            }

            // backtrack to previous filed
            g.clearCurrentField();
            g.setToField(previous);
        }
    }
}
