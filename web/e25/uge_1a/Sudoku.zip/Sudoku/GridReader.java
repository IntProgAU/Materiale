import java.io.*;
import java.util.*;

/**
 * @author Kurt Jensen
 * @version 2017-01-12
 */
public class GridReader {
    private BufferedReader input;
    private int[] data;

    /**
     * Open a file for reading lines of integers.
     *
     * The format of the file is simple: each line can contain any
     * number of integers, separated by blanks (space and tabulator).
     * Empty lines in the input file will result in a zero-length
     * array being returned by {@link getNext}.
     *
     * Lines beginning with '#' are treated as comments, and such
     * lines will be skipped. Note that the '#' must be the very first
     * character in teh line.
     *
     * @param filename   name of the file.
     *
     * @throws FileNotFoundException if the file cannot be found.
     *
     * @throws IOException if the file cannot be read.
     */
    public GridReader(String filename) throws FileNotFoundException, IOException {
        input = new BufferedReader(new FileReader(filename));
        readData();
    }
    
    public int [][] readGrid() {
        int [][] res = new int[9][9];
        for ( int x = 0; x<9; x++ ) {
            res[x] = next();
        }
        return res;
    }

    /**
     * Check for data.
     *
     * @return   if there are more lines available, return true.
     */
    private boolean hasNext() {
        return data != null;
    }

    /**
     * Get the next line of integers from the file.
     *
     * @return   next line of integers.
     *
     * @throws IOException if data cannot be read from the file.
     *
     * @throws NumberFormatException if the strings found in the file
     * cannot be converted to integers.
     */
    private int[] next() {
        int[] result = data;
        if (!hasNext())
            throw new NoSuchElementException();
        try {
            readData();
        } catch (IOException e) {
            System.err.println(e);
            throw new NoSuchElementException();
        }
        return result;
    }

    /**
     * Read a line of data from the file.
     *
     * Lines starting with a '#' are treated as comments and skipped,
     * empty lines produce an empty array, and EOF gives a null.
     */
    private void readData() throws IOException {
        String line = "#";

        while (line != null && line.length() > 0 && line.charAt(0) == '#') {
            line = input.readLine();
            if (line != null)
                line = line.trim();
        }

        if (line == null) {
            data = null;
        } else if (line.length() == 0) {
            data = new int[0];
        } else {
            String[] parts = line.split("[ \t]+");
            data = new int[parts.length];
            
            for (int i = 0; i < parts.length; i++) {
                data[i] = Integer.parseInt(parts[i]);
            }
        }
    }
}
