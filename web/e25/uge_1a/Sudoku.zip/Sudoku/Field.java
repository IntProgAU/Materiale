
/**
 * Write a description of class Field here.
 * 
 * @author Kurt Jensen
 * @version 2017-01-12
 */
public class Field
{
    public int x, y;
    
    public Field(int x, int y) {
        this.x = x; this.y = y;
    }
}
