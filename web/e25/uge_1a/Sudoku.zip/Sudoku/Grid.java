import java.util.*;

/**
 * The Grid class represents a 9x9 Sudoku grid
 * 
 *  @author Kurt Jensen
 *  @version 2017-012-12
 */
public class Grid {
    private int[][] g;
    private int x, y;
    
    public Grid(String filename) {
        x = 0; y = -1;
        try {
            GridReader r = new GridReader(filename);
            g = r.readGrid();
        } catch (Exception e) {}
    }
    
    /**
     * Sets the current field to value v
     */
    public void setFieldValue(int v) {
        g[x][y] = v;
    }
    
    /**
     * Clears the current field
     */
    public void clearCurrentField() {
        setFieldValue(0);
    }
    
    /**
     * Set the current field to f
     */
    public void setToField(Field f) {
        x = f.x; y = f.y;
    }
    
    /**
     * Return the coordinates of the current field
     */
    public Field currentField() {
        return new Field(x, y);
    }

    /**
     * Advance the current field to the next unfilled
     */
    public void advanceToNextUnfilled() {
        do {
            y++;
            if ( y == 9 ) {
                y = 0;
                x++;
            }
        } while ( g[x][y] != 0 );
    }
    
    /**
     * Return the number of unfilled fields
     */
    private int unfilled() {
        int res = 0;
        for (int i = 0; i<9; i++ ) {
            for ( int j = 0; j<9; j++ ) {
                if ( g[i][j] == 0 ) {
                    res++;
                }
            }
        }
        return res;
    }
    
    /**
     * Return whether all fields are filled
     */
    public boolean allFilled() {
        return unfilled() == 0;
    }
    
    /**
     * Return whether c is a promissing candidate
     * for the current field
     */
    public boolean promissing(int c) {
        return rowPromissing(c)
            && columnPromissing(c)
            && blockPromissing(c);
    }
    
    /**
     * Return whether c is a promissing candidate
     * for the current row
     */
    private boolean rowPromissing(int c) {
        for ( int j = 0; j<9; j++ ) {
            if ( g[x][j] == c ) {
                return false;
            }
        }
        return true;
    }
    
    /**
     * Return whether c is a promissing candidate
     * for the current column
     */
    private boolean columnPromissing(int c) {
        for ( int i = 0; i<9; i++ ) {
            if ( g[i][y] == c ) {
                return false;
            }
        }
        return true;
    }
    
    /**
     * Return whether c is a promissing candidate for the current block
     */
    private boolean blockPromissing(int c) {
        for ( int i = down(x); i<down(x)+3; i++ ) {
            for ( int j = down(y); j<down(y)+3; j++ ) {
                if ( g[i][j] == c ) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Return the largest multiplum of 3 not greater than a
     */
    private int down(int a) {
        return a/3 * 3;
    }
    
    /**
     * Return whether divisor divides dividend
     */
    private boolean divides(int divisor, int dividend) {
        return dividend % divisor == 0;
    }

    /**
     * Print the grid
     */
    public void printGrid() {
        for ( int i = 0; i<9; i++ ) {
            if ( divides(3,i) ) {
                System.out.println("------------------------- ");
            }
            printRow(i);
        }
        System.out.println("------------------------- ");
        System.out.println();
    }
    
    /**
     * Print a row of the grid
     */
    private void printRow(int i) {
        for ( int j = 0; j<9; j++ ) {
            if ( divides(3, j) ) {
                System.out.print("| ");
            }
            if ( g[i][j] != 0 ) {
                System.out.print(g[i][j] + " ");
            }
            else {
                System.out.print("  ");
            }
        }
        System.out.println("| ");
    }
}
