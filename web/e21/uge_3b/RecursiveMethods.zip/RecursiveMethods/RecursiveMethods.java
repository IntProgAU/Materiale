
/**
 * Recursive and iterative methods for calucalation of faculty and fibonacci.
 * Recursive method to check wether a String is a palindrome.
 * 
 * @author Kurt Jensen.
 * @version 2017-01-12.
 */
public class RecursiveMethods
{
    /**
     * Calculates n! recursion.
     */
    public static int faculty(int n) {
        if (n == 1) {return 1;}
        return faculty(n-1) * n;
    }

    /**
     * Calculates n! by iteration.
     */
    public static int facultyLoop(int n) {
        int result = 1;
        for (int i=1; i<=n; i++) {
            result *= i;
        }
        return result;
    }

    /**
     * Calculates n'th fibonacci number by recursion.
     */
    public static int fibonacci(int n) {
        if (n == 1) {return 0;}
        if (n == 2) {return 1;}
        return fibonacci(n-2) + fibonacci(n-1);
    }

    /**
     * Calculates n'th fibonacci number by iteration.
     */
    public static int fibonacciLoop(int n) {
        if (n == 1) return 0;
        int first = 0;
        int second = 1;
        int temp;
        for (int i=3; i<=n; i++) {
            temp = second;
            second += first;
            first = temp;
        }
        return second;

    }

    /**
     * Checks whether the parameter is a palindrome by recursion.
     */
    public static boolean palindrome(String s) {
        int length = s.length();
        if(length <= 1) {return true;}        

        // Divide string
        char first = s. charAt(0);
        char last = s.charAt(length-1);
        String middle = s.substring(1, length-1);

        if(first == last) {
            return palindrome(middle);  // Recursive call
        }
        else {
            return false;
        }
    }
}

