/**
 * This class models a DieCup (rafleb�ger)
 * 
 * @author Kurt Jensen
 * @version 2020-08-12
 **/
public class DieCup {
    private Die d1;   // First die
    private Die d2;   // Second die
    
    /**
     * Constructor for DieCup objects
     */
    public DieCup() {
        
    }
    
     /**
     * Obtain a new number of eyes for both dice
     */
    public void roll() {
        
    }
    
    /**
     * Return the sum of the number of eyes shown by the two dice
     */
    public int getEyes() {
        return 0;
    }
}
